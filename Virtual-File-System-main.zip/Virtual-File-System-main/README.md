# Virtual-File-System
This project provides functionality of file system same as Linux File  System. It offers essential commands, system calls, and file system  implementations through a modified shell. This project includes implementation of all necessary data structures of file systems like Incore Inode Table, File Table, UAREA, User File  Descriptor table.

IMPLEMENTATION:

![ss1](https://user-images.githubusercontent.com/93419528/187506774-ab931478-b418-4777-a546-c908b88ef3a9.png)
![ss2](https://user-images.githubusercontent.com/93419528/187506907-7118d4df-685b-4d2e-bf94-0d95089835c9.png)
![ss3](https://user-images.githubusercontent.com/93419528/187506931-bfa7be60-bd47-4dd3-90b2-647dca537bf0.png)
![ss4](https://user-images.githubusercontent.com/93419528/187506961-3d309bd4-1401-4748-8b79-e9a933f2fe0a.png)
